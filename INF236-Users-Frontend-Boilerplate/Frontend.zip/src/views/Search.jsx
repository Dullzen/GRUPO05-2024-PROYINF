import React, { useState } from "react";
import { Link } from "react-router-dom";
import SearchForm from '../components/SearchForm';

export default function Search() {
  const [results, setResults] = useState([]);

  const handleSearchResults = (data) => {
    setResults(data);
  };

  return (
    <div>
      <h1>Buscador de Archivos</h1>
      <SearchForm onSearchResults={handleSearchResults} />
      <div style={{ display: "flex", flexWrap: "wrap" }}>
        {results.map((result, index) => (
          <Link key={index} to={`/archivoDicom/${result.patientId}`}>
            <div
              style={{
                margin: "10px",
                width: "150px",
                height: "150px",
                border: "1px solid #ccc",
                borderRadius: "5px",
                textAlign: "center",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                textDecoration: "none",
                color: "inherit",
              }}
            >
              {result.patientName} - {result.patientId}
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
